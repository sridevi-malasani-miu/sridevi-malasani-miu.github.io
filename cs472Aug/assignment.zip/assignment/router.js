const express = require('express');
var path = require("path");
var controller = require("./controller")

const router = express.Router();
router.get("/",controller.show)

module.exports = router;
