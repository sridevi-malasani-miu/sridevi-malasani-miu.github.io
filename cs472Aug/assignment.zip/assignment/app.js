const express = require('express');
const app = express();
var ejs = require("ejs");
var router = require('./router')
app.listen(80, () => {
    console.log('Your Server is running on 3000');
})

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

//EJS Engine
app.set('view engine', 'html');
app.engine('html', ejs.renderFile);
// app.set('views', path.join(__dirname,"myDir"));

app.use("/",router);