var model = require('./model')
exports.show = function(req,res,next){
    res.render('edit',model);
}