const express = require('express');
const app = express();
var path = require("path");

app.listen(80, function() {
    console.log('Your Server is running on 80');
});

//Read the parameters from post request
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, '../client/build')));

app.get("/home", function (req, res, next) {
    res.sendFile(path.join(__dirname,'public','home.html'))
})

app.post("/postLanguage", function (req, res, next) {
   console.log(req.body);
   res.redirect("/skill")
})

app.get("/skill", function (req, res, next) {
    res.sendFile(path.join(__dirname,'public','skill.html'))
 })

 app.post("/postSkill", function (req, res, next) {
    console.log(req.body);
    res.redirect("/preview")
 })

 app.get("/preview", function (req, res, next) {
    console.log(req.body);
    res.sendFile(path.join(__dirname,'../client/build','index.html'))
 })

